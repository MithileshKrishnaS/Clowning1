// var a=greatestOfTwoNumbers(10,5);
function greatestOfTwoNumbers(x, y)
{
    if(x>y)
    {
        console.log(x);
        return x;
    }
    else
    {
        console.log(y);
        return y;
    }
}
