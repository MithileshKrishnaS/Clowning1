describe('Greater of two numbers',function()
{
    it('find greatest of two numbers',function()
    {
        var a=1,b=2;
        expect(greatestOfTwoNumbers(a,b)).toBe(b);
        expect(greatestOfTwoNumbers(2,3)).toBe(3);
        expect(greatestOfTwoNumbers(2,4)).toBe(4);
        expect(greatestOfTwoNumbers(6,1)).toBe(6);
    });
})